# WebView2 / TWebFrame2 정적 렌더링 검증

원본 1,000문서는 `../rendering-stress/cases`에 유지한다. fixture 내용과 ID로 엔진을 보정하지 않는다. 페이지 JavaScript 실행은 끈다. 캡처 도구의 JavaScript는 기준 브라우저의 DOM/CSSOM을 읽는 측정용이며 DOM을 수정하지 않는다.

## 두 배율의 PNG 캡처

저장소 루트에서 PowerShell로 실행한다. VS 2019 v142 C++ 도구, 저장소의 WebView2 SDK/Runtime, Skia DLL을 사용한다.

```powershell
& tests\rendering-verification\Capture-WebView2.ps1
& tests\rendering-verification\Capture-WebView2.ps1 -Software
& tests\rendering-verification\Capture-TWebFrame2.ps1
```

각 스크립트는 기본적으로 전체 1,000문서를 **800×600 CSS viewport, 96/144 DPI**로 캡처한다. 96 DPI의 PNG는 800×600, 144 DPI의 PNG는 1200×900이다. DPI를 페이지 zoom과 중복 적용하지 않으며 PNG를 재샘플링하지 않는다. WebView2 Controller3의 raw pixel bounds/rasterization scale과 native `CaptureRenderingSnapshot`의 명시적 DPI를 사용한다. 호스트는 Per-Monitor-V2 awareness를 설정한다.

150%에서 CSS viewport를 정확히 유지하려면 폭/높이가 짝수여야 한다. 홀수 CSS 크기는 1.5배에서 반 픽셀이 되어 정수 HWND bounds와 동일한 viewport를 만들 수 없으므로 도구가 거부한다. 문서 내부의 분수 CSS 길이는 그대로 테스트한다.

```powershell
& tests\rendering-verification\Capture-WebView2.ps1 -CaseId 0001-nested-grid -Dpi 96,144 -Width 1280 -Height 800 -TimeoutSeconds 60
& tests\rendering-verification\Capture-TWebFrame2.ps1 -ParallelDpi
& tests\rendering-verification\Capture-TWebFrame2.ps1 -ParallelDpi -Workers 3
```

`-OutputDirectory`, `-BuildDirectory`, `-SkipBuild`를 지정할 수 있다. 기존 출력은 덮어쓰지 않는다. fixture HTML/CSS SHA-256이 원본 manifest와 다르면 캡처를 거부한다. 두 배율을 동시에 돌리려면 `-ParallelDpi`를 사용한다. WebView2 기본 제한 시간은 30초이며, 실패 문서는 `error.txt`로 남기고 다음 문서를 계속 처리한다. 실패 복구 시 이 도구가 생성한 해당 WebView2 프로세스만 종료한다.

native `-Workers`는 배율별 1~6개 독립 프로세스로 문서를 나눈다. 두 DPI와 workers 3은 총 6개 프로세스다. 서로 겹치지 않는 문서만 각 프로세스에 할당하며, PNG를 변경하지 않고 결과를 합친다. worker 요약·로그·실행 파일 해시는 보관한다. 6개 smoke 캡처는 단독 실행과 병렬 실행의 PNG 바이트가 모두 같았다. `Run-Verification.ps1`은 `-NativeWorkers 3`을 기본값으로 사용한다.

이 검증은 지정된 viewport의 첫 화면을 비교한다. 스크롤 아래 영역 전체와 모든 CSS 조합의 완전 검증을 의미하지 않는다. 추가 viewport는 별도 run으로 실행할 수 있다. 현재 데스크톱의 실제 HWND DPI는 96이다. 명시적 144 DPI 캡처와 실제 Windows 디스플레이를 150%로 바꾼 HWND/모니터 이동 테스트는 구분한다. `summary.json`의 `dpi`는 요청값, `actualWindowDpi`는 실제 호스트값이다. native `layout.json`에는 실제 snapshot의 viewport/DPI/계약 버전과 원본 PNG를 기록한다. 전체 DOM/텍스트 진단을 추가로 보관하려면 `Capture-TWebFrame2.ps1 -FullDiagnostics`를 사용한다. 진단 출력 범위는 PNG 렌더링에 영향을 주지 않으며 상세/간단 모드의 PNG 바이트와 공통 메타데이터가 같은 것을 확인했다. 현재 snapshot API는 기존 `[data-case-node]`의 box만 기록하므로 새 fixture의 `[data-probe]` box 목록은 비어 있다. 해당 좌표 진단에는 아래 `Inspect-Layout`을 사용한다.

## 픽셀 비교와 GPU/CPU 차이

Pillow/NumPy가 있는 Python을 사용한다.

```powershell
python tests\rendering-verification\compare.py --reference <WebView2출력> --software <software출력> --native <TWebFrame2출력> --output <새비교폴더>
```

RGBA 채널 오차 허용값은 0이다. 같은 위치의 전체 RGBA가 모두 같아야 동일 픽셀이다. 누락/실패 캡처, PNG 크기 불일치, DPI 불일치는 실패다. ID별 예외나 텍스트 주변의 일괄 AA 마스크는 사용하지 않는다.

GPU/CPU 제외는 같은 원본과 런타임, 같은 캡처 실행 파일, 실제 GPU rasterization/compositing 활성·비활성 진단, 동일 기준 DOM 측정이 모두 확인된 경우만 허용한다. 그 경우에도 **native RGBA가 별도 software WebView2 RGBA와 정확히 같고, GPU와 software가 실제로 다른 픽셀**만 제외한다. 단순히 가까운 색이나 1픽셀 차이라는 이유로 제외하지 않는다.

현재 전체 기준 run의 `graphics.json`은 첫 browser generation에서 측정한 backend 상태다. 25문서마다 같은 옵션으로 browser를 다시 만들지만 각 generation의 backend 상태를 별도로 실측한 것은 아니다. 결과에는 제외 전의 `exactPixelPercent`도 함께 기록한다.

## 전체 실행과 보관

```powershell
& tests\rendering-verification\Run-Verification.ps1 -PythonPath <python.exe절대경로>
# 기본 동작은 전체 2,000쌍 통과 후 산출물 정리다.
```

`verification-result.txt`에 간단한 결과를 남긴다. 실패 시 PNG/상세 로그/빌드는 재현을 위해 `.work`에 보관한다. 전체 통과 후 `Clean-VerifiedArtifacts.ps1 -ComparisonDirectory <비교폴더>`는 입력/보관 ZIP을 확인하고, 현재 도구·누적 회귀 프로젝트·공통 엔진 소스·간단한 결과를 새 ZIP으로 보관한 뒤 검증 `.work`와 이전 smoke artifact 폴더를 삭제한다. 원본 문서, generator, manifest, ZIP, 캡처/비교 도구, 누적 회귀 프로젝트는 유지한다. 다른 Python 경로를 사용하면 `-PythonPath`로 전달한다.

`preserved/inputs-tools-and-engine-before.zip`은 작업 시작 당시 1,000문서·도구·엔진 소스의 보관본이다. `catalog.json`에 파일별/ZIP SHA-256을 남겼다. 보관본을 덮어쓰지 않는다.

`preserve_tools.py`는 원본 ZIP의 모든 항목과 현재 원본 문서를 확인하고, 추가된 도구/회귀 프로젝트/공통 엔진 변경을 새 ZIP으로 누적 보관한다. `common-engine-changes.patch`는 기존 사용자 변경을 기준으로 이번 작업이 추가한 변경만 담는다.

## 누적 회귀 프로젝트

- `FontLogicalRegression.vcxproj`: 부모/루트 상대 글꼴, line-height 상속, 논리 속성의 방향·우선순위·선언 순서·revert-layer.
- `ViewportDpiRegression.vcxproj`: 일반/강제/숨김 스크롤바, stable/both-edges, viewport와 percentage/vw의 구분, DPI 물리 픽셀 반올림, resize.
- `AutoOverflowRegression.vcxproj`: 실제 배치 후 자동 gutter 판단, 인접 margin collapse, 블록/그리드/flex/RTL, 반복 relayout에서 scroll 좌표 안정성. WebView2에서 독립 측정한 96/144 DPI 좌표를 사용한다. 수정 전 150개 검사 중 8개 실패, 수정 후 150개 모두 통과했다.
- `TableFormattingRegression.vcxproj`: DOM을 바꾸지 않는 익명 테이블 행/셀/부모 생성, 첫 header/footer 그룹의 시각 순서, RTL 열·셀 병합, inline-table, collapsed border와 절대 위치 크기, HTML UA 스타일과 CSS 상속. 독립 WebView2 좌표 47개를 두 DPI에서 초기 배치/반복 relayout으로 확인한다. 392개 검사와 작은 회귀 문서의 96/144 DPI PNG 전체 RGBA 비교가 통과했다. 기대 TSV는 회귀 입력으로 보관하며 원본 1,000문서에 대한 보정에 사용하지 않는다.
- `OverflowPaddingRegression.vcxproj`: visible 자손의 끝 padding 중복 방지, 가로/세로 scrollbar 상호 유발, 자동 높이 요소와 뒤 요소의 위치, CSSOM scroll/client 크기, 두 축 scroll offset의 반복 relayout 안정성. 두 DPI에서 WebView2로 독립 측정한 13개 probe를 사용한다. 수정 전 168개 중 40개 실패, 수정 후 모두 통과했다.
- `TextSpacingRegression.vcxproj`: word-spacing 상속과 양수/음수 간격, font-relative 자간의 computed length 상속, NBSP와 고정 폭 공백의 구분, 공백 축약/보존, tab-size, RTL, 간격에 따른 2줄/3줄 배치. 두 DPI의 독립 WebView2 좌표/스타일 20개 probe로 244개 검사와 PNG 전체 RGBA 비교가 통과했다. 수정 전 244개 중 80개가 실패했다.
- `test_compare.py`: 작은 RGBA 차이도 실패, 크기/alpha 차이, 근거 없는 backend 제외 금지.

`Run-Regressions.ps1`로 여섯 C++ 회귀 프로젝트(1,176개 검사)와 Python 픽셀 비교 회귀(9개)를 함께 실행할 수 있다. `Run-Verification.ps1`은 이 검사들이 통과한 뒤 전체 문서를 캡처한다.

이 스크립트는 `Run-ExactPngRegressions.ps1`도 실행한다. 테이블·텍스트 간격의 작은 회귀 문서를 두 엔진과 두 DPI에서 새로 캡처한 4쌍은 전체 RGBA가 같아야 통과한다. backend 제외나 리사이즈는 적용하지 않는다. 입력/실행 파일 해시와 결과는 `.work`에 기록하며 전체 1,000문서 검증과 구분한다. PNG 회귀만 다시 실행하려면 `Run-ExactPngRegressions.ps1 -BuildDirectory <빌드폴더>`를 사용한다.

테이블 구조·행 그룹·RTL 배치 규칙은 [CSS 2.1 Tables](https://www.w3.org/TR/CSS2/tables.html#anonymous-boxes)를 따르며, 픽셀 일치 여부는 현재 WebView2에서 별도로 검증한다.

텍스트 간격과 상속 규칙은 [CSS Text 3 Spacing](https://www.w3.org/TR/css-text-3/#spacing)을 참조하며, 공백·tab·줄바꿈의 실제 좌표와 픽셀은 현재 WebView2에서 별도로 검증한다.

`Inspect-Layout.vcxproj`는 원본 HTML/CSS를 공통 엔진으로 읽는 진단용 프로젝트다. `Inspect-Layout.exe <index.html> <output.json> [dpi] [selector]`로 요소의 rect/content/scroll/style을 기록한다. selector는 출력 대상만 지정하며 DOM·스타일·레이아웃을 변경하지 않는다. 이 도구는 800×600 CSS viewport를 사용하며, 외부 이미지 로딩과 페이지 JavaScript 실행을 수행하지 않는다. 이미지가 배치에 영향을 주는 경우 PNG 캡처 호스트의 결과를 기준으로 삼는다.

프로젝트/소스는 누적 보관한다. 실행 파일, object/lib/PDB, 복사한 DLL은 `.work`에만 생성하고 전체 검증 통과 후 정리한다.
