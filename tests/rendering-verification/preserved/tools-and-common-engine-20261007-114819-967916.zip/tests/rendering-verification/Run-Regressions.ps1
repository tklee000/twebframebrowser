param([string]$BuildDirectory=(Join-Path $PSScriptRoot '.work\build'),[string]$PythonPath='',[switch]$SkipEngineBuild)
$ErrorActionPreference='Stop'
$buildFull=[IO.Path]::GetFullPath($BuildDirectory)
if(!$SkipEngineBuild){& (Join-Path $PSScriptRoot 'Build-Capture.ps1') -BuildDirectory $buildFull}
$msbuild='C:\Program Files (x86)\Microsoft Visual Studio\2019\Community\MSBuild\Current\Bin\MSBuild.exe'
foreach($project in @('FontLogicalRegression','ViewportDpiRegression','AutoOverflowRegression','TableFormattingRegression','OverflowPaddingRegression')){
    & $msbuild (Join-Path $PSScriptRoot ($project+'.vcxproj')) /t:Build /p:Configuration=Release /p:Platform=x64 /p:BuildProjectReferences=false "/p:OutDir=$buildFull\bin\" "/p:IntDir=$buildFull\obj\$project\" /v:minimal /nologo
    if($LASTEXITCODE -ne 0){throw "Regression build failed: $project"}
    if($project -in @('AutoOverflowRegression','TableFormattingRegression','OverflowPaddingRegression')){
        $regressionFixture=if($project -eq 'AutoOverflowRegression'){'auto-overflow'}elseif($project -eq 'TableFormattingRegression'){'table-formatting'}else{'overflow-padding'}
        & (Join-Path $buildFull ('bin\'+$project+'.exe')) (Join-Path $PSScriptRoot ('regressions\'+$regressionFixture))
    }else{& (Join-Path $buildFull ('bin\'+$project+'.exe'))}
    if($LASTEXITCODE -ne 0){throw "Regression failed: $project"}
}
if(!$PythonPath){$PythonPath=Join-Path $env:USERPROFILE '.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe'}
if(!(Test-Path -LiteralPath $PythonPath)){throw 'Pass -PythonPath for a Python runtime with Pillow and NumPy.'}
& $PythonPath -m unittest discover -s $PSScriptRoot -p test_compare.py -v
if($LASTEXITCODE -ne 0){throw 'Pixel comparator regression failed.'}
Write-Output 'Common CSS/layout/DPI and strict pixel comparator regressions passed.'
